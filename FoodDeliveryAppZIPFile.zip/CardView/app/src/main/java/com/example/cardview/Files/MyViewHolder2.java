package com.example.cardview.Files;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;

public class MyViewHolder2 extends RecyclerView.ViewHolder {
    TextView txtFoodName;
    TextView txtFoodPrice;
    ImageView foodImageView;
    public MyViewHolder2(@NonNull View itemView) {
        super(itemView);
        txtFoodName=itemView.findViewById(R.id.foodName);
        txtFoodPrice=itemView.findViewById(R.id.foodPrice);
        foodImageView=itemView.findViewById(R.id.foodImageView);
    }
}
