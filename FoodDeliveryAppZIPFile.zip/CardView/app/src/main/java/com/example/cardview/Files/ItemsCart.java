package com.example.cardview.Files;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cardview.R;

public class ItemsCart extends AppCompatActivity {
    TextView txtName;
    TextView txtPrice;
    ImageView imageView;
    Button add;
    SharedPreferences sp;
    TextView txtItemCount;
    ViewAllActivity v1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_items_cart);
            txtName = findViewById(R.id.txtRecipeName);
            txtPrice = findViewById(R.id.txtFoodPrice);
            imageView = findViewById(R.id.foodImageView);
            v1=new ViewAllActivity();
            Toast.makeText(this, "Inside ItemCart", Toast.LENGTH_SHORT).show();
            Intent intent = getIntent();
            String foodName = intent.getStringExtra("FoodName");
            String foodPrice = intent.getStringExtra("FoodPrice");
            int foodImage = intent.getIntExtra("FoodImage", 0);
            txtName.setText(foodName);
            txtPrice.setText(foodPrice);
            imageView.setImageResource(foodImage);
            sp = getSharedPreferences("CheckOut", MODE_PRIVATE);
            SharedPreferences.Editor editor=sp.edit();
            add=findViewById(R.id.btnaddToCart);
            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(ItemsCart.this, "Name : "+txtName.getText().toString(), Toast.LENGTH_SHORT).show();
                    try {
                        editor.putInt("count", getTotalItems() + 1);
                        editor.apply();
                        ViewAllActivity.updateItemCount(getTotalItems(),txtName.getText().toString(),txtPrice.getText().toString(),foodImage);
                    }
                    catch(Exception e){
                        Toast.makeText(ItemsCart.this, "Exception"+e.toString(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
    }
    public int getTotalItems() {
        return sp.getInt("count", 0);
    }
    }