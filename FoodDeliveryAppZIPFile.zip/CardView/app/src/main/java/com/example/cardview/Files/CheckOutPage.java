package com.example.cardview.Files;

import android.content.Intent;
import android.content.SharedPreferences;
import android.opengl.GLDebugHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CheckOutPage extends AppCompatActivity {
    TextView txtItemView;
    MyAdapter2 myAdapter;
    TextView totalAmountHint;
    RecyclerView recyclerView;
    Button btnOk;
    Button btnPayNow;
    ImageView editAddress;
    EditText editTxtAddress;
    TextView txtTotalValue;
    private String address;
    ArrayList<GetData>listOfItemSelected;
    TextView enteredTextViewAddress,addressTextView,deliveryToTextView;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ArrayList<GetData> listOfIceCreams = new ArrayList<>();
        listOfIceCreams = new ArrayList<>();
        listOfIceCreams.add(new GetData("Cotton Candy", "240", R.drawable.icecream));
        listOfIceCreams.add(new GetData("Bavarian Chocolate", "300", R.drawable.bavarian_ice_cream));
        listOfIceCreams.add(new GetData("Black Current", "450", R.drawable.black_current_ice_cream));
        listOfIceCreams.add(new GetData("Mango", "100", R.drawable.mango_ice_cream));
        listOfIceCreams.add(new GetData("Banana Flavour", "560", R.drawable.banana_ice_cream));
        listOfIceCreams.add(new GetData("Cookies and Cream", "150", R.drawable.cookies_cream_ice_cream));
        listOfIceCreams.add(new GetData("BlueBerry Flavour", "400", R.drawable.blueberry_ice_cream));
        listOfIceCreams.add(new GetData("Rocky Road", "450", R.drawable.rocky_road_ice_cream));

        setContentView(R.layout.activity_check_out_page);
        txtTotalValue=findViewById(R.id.txtTotalValue);
        btnPayNow=findViewById(R.id.buttonPayNow);
        totalAmountHint=findViewById(R.id.totalAmountHint);
        sharedPreferences=getSharedPreferences("Address",MODE_PRIVATE);
        editor=sharedPreferences.edit();
//        address = sharedPreferences.getString("AddressLine","");



        SharedPreferencesStorage sharedPreferencesStorag=new SharedPreferencesStorage();
        ArrayList<GetData>listOfItemsToAddInCart=new ArrayList<>();
        try {
            listOfItemsToAddInCart = sharedPreferencesStorag.getListOfItems(this);
        }
        catch (Exception e){
            Toast.makeText(this, "List is Empty", Toast.LENGTH_SHORT).show();
        }
        recyclerView = findViewById(R.id.recyclerViewMan);
        int price=0;
        SharedPreferencesStorage sharedPreferencesStorage=new SharedPreferencesStorage();
        for(GetData item:sharedPreferencesStorage.getListOfItems(this)){
             price+=Integer.parseInt(item.getFoodPrice());
        }
        txtTotalValue.setText(Integer.toString(price));
        String total=Integer.toString(price);
        btnPayNow.setText("Pay Now  ₹"+total);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myAdapter = new MyAdapter2(this, listOfItemsToAddInCart);
        recyclerView.setAdapter(myAdapter);
        editTxtAddress=findViewById(R.id.txtInputAddress);
        editTxtAddress.setText(address);
        btnOk=findViewById(R.id.btnOk);
        addressTextView=findViewById(R.id.addressTextView);
        enteredTextViewAddress=findViewById(R.id.enteredAddressTxt);
        deliveryToTextView=findViewById(R.id.deliveryToTextView);
        editAddress=findViewById(R.id.editAddress);
        if(sharedPreferences.getBoolean("Entered",false)){
            enteredTextViewAddress.setVisibility(View.VISIBLE);
            addressTextView.setVisibility(View.GONE);
            btnOk.setVisibility(View.GONE);
            btnPayNow.setVisibility(View.VISIBLE);
            deliveryToTextView.setVisibility(View.VISIBLE);
            totalAmountHint.setVisibility(View.VISIBLE);
            txtTotalValue.setVisibility(View.VISIBLE);
            editAddress.setVisibility(View.VISIBLE);
            editTxtAddress.setVisibility(View.GONE);
            enteredTextViewAddress.setText(sharedPreferences.getString("AddressLine",""));

        }
            btnOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Address = editTxtAddress.getText().toString();
                    if(!Address.isEmpty()) {
                        btnOk.setVisibility(View.GONE);
                        addressTextView.setVisibility(View.GONE);
                        editTxtAddress.setVisibility(View.GONE);
                        deliveryToTextView.setVisibility(View.VISIBLE);
                        txtTotalValue.setVisibility(View.VISIBLE);
                        totalAmountHint.setVisibility(View.VISIBLE);
                        btnPayNow.setVisibility(View.VISIBLE);
                        enteredTextViewAddress.setVisibility(View.VISIBLE);
                        enteredTextViewAddress.setText(Address);
                        editor.putString("AddressLine", editTxtAddress.getText().toString());
                        editor.putBoolean("Entered", true);
                        editor.apply();
                        editAddress.setVisibility(View.VISIBLE);
                    }
                    else{
                        Toast.makeText(CheckOutPage.this, "Please Enter Address", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        editAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnOk.setVisibility(View.VISIBLE);
                addressTextView.setVisibility(View.VISIBLE);
                editTxtAddress.setVisibility(View.VISIBLE);
                deliveryToTextView.setVisibility(View.GONE);
                enteredTextViewAddress.setVisibility(View.GONE);
                editAddress.setVisibility(View.GONE);
                btnPayNow.setVisibility(View.GONE);
                editor.putBoolean("Entered",false);
                editTxtAddress.setText(address);
                totalAmountHint.setVisibility(View.GONE);
                txtTotalValue.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        editTxtAddress.setText(address);
    }
}