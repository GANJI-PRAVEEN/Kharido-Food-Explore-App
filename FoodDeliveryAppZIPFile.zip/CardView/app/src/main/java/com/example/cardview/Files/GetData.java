package com.example.cardview.Files;

import java.io.Serializable;

public class GetData implements Serializable {
    String foorName;
    int foodImage;
    String foodPrice;

    public GetData(String foorName, String foodPrice, int foodImage) {
        this.foorName = foorName;
        this.foodPrice = foodPrice;
        this.foodImage = foodImage;
    }

    public String getFoorName() {
        return foorName;
    }

    public void setFoorName(String foorName) {
        this.foorName = foorName;
    }

    public int getFoodImage() {
        return foodImage;
    }

    public void setFoodImage(int foodImage) {
        this.foodImage = foodImage;
    }

    public String getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(String foodPrice) {
        this.foodPrice = foodPrice;
    }
}
