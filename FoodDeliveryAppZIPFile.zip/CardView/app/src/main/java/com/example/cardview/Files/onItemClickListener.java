package com.example.cardview.Files;

public interface onItemClickListener {
    public void onItemClicked(int position);
    public void onAddBtnClicked(int position);
}
