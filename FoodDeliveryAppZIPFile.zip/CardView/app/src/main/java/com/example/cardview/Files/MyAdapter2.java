package com.example.cardview.Files;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;

import java.util.ArrayList;

public class MyAdapter2 extends RecyclerView.Adapter<MyViewHolder2> {
    Context context;
    ArrayList<GetData> listOfItems;
    onItemClickListener listener;

    public void setFilteredList(ArrayList<GetData>filteredList){
        this.listOfItems=filteredList;
        notifyDataSetChanged();
    }

    public MyAdapter2(Context context, ArrayList<GetData>listOfItems){
        this.context=context;
        this.listOfItems=listOfItems;
    }
    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MyViewHolder2 myViewHolder=new MyViewHolder2(LayoutInflater.from(context).inflate(R.layout.check_out_item_view,parent,false));
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, int position) {
        holder.txtFoodName.setText(listOfItems.get(position).getFoorName());
        holder.txtFoodPrice.setText(listOfItems.get(position).getFoodPrice());
        holder.foodImageView.setImageResource(listOfItems.get(position).getFoodImage());
    }

    @Override
    public int getItemCount() {
        return listOfItems.size();
    }
}
