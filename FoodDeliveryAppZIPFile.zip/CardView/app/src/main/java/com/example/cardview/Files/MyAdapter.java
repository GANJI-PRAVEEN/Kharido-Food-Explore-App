package com.example.cardview.Files;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    Context context;
    ArrayList<GetData> listOfItems;
    onItemClickListener listener;
    public void setFilteredList(ArrayList<GetData>filteredList){
        this.listOfItems=filteredList;
        notifyDataSetChanged();
    }

    public MyAdapter(Context context,ArrayList<GetData>listOfItems,onItemClickListener listener){
        this.context=context;
        this.listOfItems=listOfItems;
        this.listener=listener;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MyViewHolder myViewHolder=new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_view,parent,false));
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.txtFoodName.setText(listOfItems.get(position).getFoorName());
        holder.txtFoodPrice.setText(listOfItems.get(position).getFoodPrice());
        holder.foodImageView.setImageResource(listOfItems.get(position).getFoodImage());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener!=null){
                    listener.onItemClicked(position);
                }
            }
        });
        holder.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener!=null){
                    listener.onAddBtnClicked(position);
                }
            }

        });
    }

    @Override
    public int getItemCount() {
        return listOfItems.size();
    }
}
