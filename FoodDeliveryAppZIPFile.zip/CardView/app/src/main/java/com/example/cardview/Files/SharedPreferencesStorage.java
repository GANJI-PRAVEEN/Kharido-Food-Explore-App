package com.example.cardview.Files;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Pair;
import android.view.Display;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class SharedPreferencesStorage {

    public void saveListOfItems(Context context,ArrayList<GetData>listOfItems){
        SharedPreferences sharedPreferences=context.getSharedPreferences("Storage",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        Gson gson=new Gson();
        String list=gson.toJson(listOfItems);
        editor.putString("List",list);
        editor.apply();

    }
    public ArrayList<GetData> getListOfItems(Context context){
        SharedPreferences sharedPreferences1=context.getSharedPreferences("Storage",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences1.edit();
        String list=sharedPreferences1.getString("List","");
        if(list.equals("")){
            ArrayList<GetData> t = new ArrayList<GetData>();
            return t;

        }
        Gson gson=new Gson();
        Type type = new TypeToken<ArrayList<GetData>>() {}.getType();
        return gson.fromJson(list,type);
    }

    public void clearList(Context context){
        SharedPreferences sharedPreferences=context.getSharedPreferences("Storage",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
