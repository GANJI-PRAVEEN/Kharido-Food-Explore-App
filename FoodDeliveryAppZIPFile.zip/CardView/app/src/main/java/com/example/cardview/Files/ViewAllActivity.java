package com.example.cardview.Files;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class ViewAllActivity extends AppCompatActivity implements onItemClickListener {
    ArrayList<GetData> selectedList;
    private MyAdapter myAdapter;
    RecyclerView recyclerView;
    SharedPreferences sp;
    SharedPreferences.Editor editor;

    TextView txtNoData;
    ArrayList<GetData> listForCheckOut;
    TextView txtItemCount;
    ArrayList<GetData> listOfIceCreams;
    SharedPreferencesStorage sharedPreferencesStorage1;
    ArrayList<GetData> listOfBiryani;
    ArrayList<GetData> listOfSnacks;
    ImageView deleteImage;
    LinearLayout bottomBar;
    private final String COUNT = "count";
    private SharedPreferencesStorage sharedPreferencesStorage;
    private int ind;
    private int itemCount = 0;
    private static WeakReference<TextView> txtItemCountRef;
    private static WeakReference<ArrayList<GetData>>listForCheckOutRef;

    public ViewAllActivity(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all); // Ensure this layout file exists



        txtNoData = findViewById(R.id.noDatatxt);
        txtItemCount = findViewById(R.id.itemsCount2);
        txtItemCountRef = new WeakReference<>(txtItemCount);
        listForCheckOut = new ArrayList<>();
        listForCheckOutRef=new WeakReference<>(listForCheckOut);
        sharedPreferencesStorage1 = new SharedPreferencesStorage();
        SharedPreferences sharedPreferences = getSharedPreferences("Storage", MODE_PRIVATE);
        SharedPreferences.Editor editor1 = sharedPreferences.edit();
        listForCheckOut = sharedPreferencesStorage1.getListOfItems(this);

        bottomBar = findViewById(R.id.bottomBar);
        sp = getSharedPreferences("CheckOut", MODE_PRIVATE);
        editor = sp.edit();

        if (sp.getBoolean("isVisible", false)) {
            bottomBar.setVisibility(View.VISIBLE);
            txtItemCount.setText(Integer.toString(getTotalItems()));
        } else {
            bottomBar.setVisibility(View.INVISIBLE);
        }

        deleteImage = findViewById(R.id.deleteCart);
        deleteImage.setOnClickListener(v -> {
            bottomBar.setVisibility(View.GONE);
            editor.putBoolean("isVisible", false);
            editor.putInt(COUNT, 0);
            editor1.putString("List","");
            SharedPreferencesStorage sharedPreferencesStorage2 = new SharedPreferencesStorage();
            sharedPreferencesStorage.clearList(this);
            editor.apply();
            recreate();
        });

        bottomBar.setOnClickListener(v -> {
            Toast.makeText(ViewAllActivity.this, "Going to Add Cart Window", Toast.LENGTH_SHORT).show();
            sharedPreferencesStorage = new SharedPreferencesStorage();
            sharedPreferencesStorage.saveListOfItems(getApplicationContext(), listForCheckOut);
            Intent intent = new Intent(ViewAllActivity.this, CheckOutPage.class);
            startActivity(intent);
        });

        // Food Adding Sector Here
        listOfIceCreams = new ArrayList<>();
        listOfIceCreams.add(new GetData("Cotton Candy", "240", R.drawable.icecream));
        listOfIceCreams.add(new GetData("Bavarian Chocolate", "300", R.drawable.bavarian_ice_cream));
        listOfIceCreams.add(new GetData("Black Current", "450", R.drawable.black_current_ice_cream));
        listOfIceCreams.add(new GetData("Mango", "100", R.drawable.mango_ice_cream));
        listOfIceCreams.add(new GetData("Banana Flavour", "560", R.drawable.banana_ice_cream));
        listOfIceCreams.add(new GetData("Cookies and Cream", "150", R.drawable.cookies_cream_ice_cream));
        listOfIceCreams.add(new GetData("BlueBerry Flavour", "400", R.drawable.blueberry_ice_cream));
        listOfIceCreams.add(new GetData("Rocky Road", "450", R.drawable.rocky_road_ice_cream));

        listOfBiryani = new ArrayList<>();
        listOfBiryani.add(new GetData("Ambur Biryani", "450", R.drawable.ambur_biryani));
        listOfBiryani.add(new GetData("Kolkata Biryani", "1200", R.drawable.kolkata_biryani));
        listOfBiryani.add(new GetData("Kashmiri Biryani", "340", R.drawable.kashmiri_ice_cream));
        listOfBiryani.add(new GetData("Sindhi Biryani", "1300", R.drawable.sindhi_biryani));

        listOfSnacks = new ArrayList<>();
        listOfSnacks.add(new GetData("Burger", "150", R.drawable.burger));
        listOfSnacks.add(new GetData("French Fries", "100", R.drawable.frenchfries));
        listOfSnacks.add(new GetData("Pizza", "200", R.drawable.pizza));
        listOfSnacks.add(new GetData("Sandwich", "230", R.drawable.sandwich_snacks));
        listOfSnacks.add(new GetData("DoNut", "300", R.drawable.donut_snacks));

        // SearchView
        SearchView searchView = findViewById(R.id.searchView);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterList(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });

        Intent intent = getIntent();

        // 2D Array
        ArrayList<ArrayList<GetData>> miniCardViewItems = new ArrayList<>();
        miniCardViewItems.add(0, listOfIceCreams);
        miniCardViewItems.add(1, listOfBiryani);
        miniCardViewItems.add(2, listOfSnacks);

        if (intent.getBooleanExtra("Biryani1", false)) {
            ind = 1;
        } else if (intent.getBooleanExtra("Snacks", false)) {
            ind = 2;
        } else {
            ind = 0;
        }

        selectedList = new ArrayList<>();
        selectedList = miniCardViewItems.get(ind);
        Toast.makeText(this, Integer.toString(ind), Toast.LENGTH_SHORT).show();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myAdapter = new MyAdapter(this, selectedList, this);
        recyclerView.setAdapter(myAdapter);
    }

    public static void updateItemCount(int count,String foodName,String foodPrice,int image) {
        try {
            TextView txtItemCount = txtItemCountRef.get();
            if (txtItemCount!= null) {
                txtItemCount.setText(Integer.toString(count));
            }
            Toast.makeText(txtItemCount.getContext(), "Items Added Mow", Toast.LENGTH_SHORT).show();
            ArrayList<GetData>listForChechout=listForCheckOutRef.get();
            listForChechout.add(new GetData(foodName,foodPrice,image));
        }
        catch(Exception e){

        }
    }

    public void filterList(String newText) {
        ArrayList<GetData> filteredList = new ArrayList<>();
        for (GetData data : selectedList) {
            if (data.getFoorName().toLowerCase().contains(newText.toLowerCase())) {
                filteredList.add(data);
            }
        }
        if (filteredList.isEmpty()) {
            txtNoData.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            txtNoData.setVisibility(View.INVISIBLE);
            myAdapter.setFilteredList(filteredList);
        }
    }

    @Override
    public void onItemClicked(int position) {
        String foodName = selectedList.get(position).getFoorName();
        String foodPrice = selectedList.get(position).getFoodPrice();
        int foodImage = selectedList.get(position).getFoodImage();
        Intent intent = new Intent(ViewAllActivity.this, ItemsCart.class);
        intent.putExtra("FoodName", foodName);
        intent.putExtra("FoodPrice", foodPrice);
        intent.putExtra("FoodImage", foodImage);
        startActivity(intent);
    }

    public void onAddBtnClicked(int position) {
        itemCount++;
        bottomBar.setVisibility(View.VISIBLE);
        editor.putInt(COUNT, getTotalItems() + 1);
        Toast.makeText(this, Integer.toString(getTotalItems()), Toast.LENGTH_SHORT).show();
        editor.putBoolean("isVisible", true);
        editor.apply();
        listForCheckOut.add(new GetData(selectedList.get(position).getFoorName(), selectedList.get(position).getFoodPrice(), selectedList.get(position).getFoodImage()));
        Toast.makeText(this, "Counter :" + itemCount, Toast.LENGTH_SHORT).show();
        txtItemCount.setText(Integer.toString(getTotalItems()));
    }

    public int getTotalItems() {
        return sp.getInt(COUNT, 0);
    }

    public ArrayList<GetData> getListOfIceCreams() {
        return listOfIceCreams;
    }

    public ArrayList<GetData> getListOfBiryani() {
        return listOfBiryani;
    }

    public ArrayList<GetData> getListOfSnacks() {
        return listOfSnacks;
    }
}
