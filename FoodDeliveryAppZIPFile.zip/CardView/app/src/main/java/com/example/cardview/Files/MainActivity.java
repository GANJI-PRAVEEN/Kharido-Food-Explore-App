
package com.example.cardview.Files;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.ims.ImsMmTelManager;
import android.util.Pair;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cardview.R;
import com.google.android.material.navigation.NavigationView;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.net.PasswordAuthentication;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sp;
    SharedPreferences.Editor editor;
    LinearLayout bottomBar;
    LinearLayout obBottomBar;
    ArrayList<GetData>listOfIceCreams;
    TextView itemCount;
    TextView t;
    ImageView deleteImage;
    private final String COUNT = "count";

    @Override
    protected void onResume() {
        super.onResume();
        updateBottomBar();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewAllActivity v=new ViewAllActivity();

//        t=findViewById(R.id.itemsCount);
        bottomBar=findViewById(R.id.bottomBarAtMain);
        itemCount = findViewById(R.id.itemsCountAtMain);
        deleteImage = findViewById(R.id.deleteCartAtMain);

//        bottomBar= findViewById(R.i)
        updateBottomBar();

        bottomBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CheckOutPage.class);
                startActivity(intent);
            }
        });

        deleteImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomBar.setVisibility(View.GONE);
                editor.putInt(COUNT,0);
                editor.apply();
                SharedPreferencesStorage sharedPreferencesStorage=new SharedPreferencesStorage();
                sharedPreferencesStorage.clearList(getApplicationContext());
                editor.putBoolean("isVisible",false);
                editor.apply();
            }
        });





//        ArrayList<GetData>dataSetOfFood=new ArrayList<>();
//        dataSetOfFood.add(new GetData("Mutton Biryani","Lucky Restaurant",R.drawable.muttonbiryani));
//        dataSetOfFood.add(new GetData("Chicken Biryani","Ashiq Restaurant",R.drawable.chickenbiryani));
//        dataSetOfFood.add(new GetData("VegManchurian","Prasad Restaurant",R.drawable.vegmanchurian));
//        dataSetOfFood.add(new GetData("Veg Noodles","Mehfil",R.drawable.vegnoodles));
//        dataSetOfFood.add(new GetData("Lays Chips","Kirana Shop",R.drawable.chips));
//        dataSetOfFood.add(new GetData("Thums Up","Shop",R.drawable.thumsup));
//        dataSetOfFood.add(new GetData("Shawarma","Mecdonalds",R.drawable.shawarma));
//        dataSetOfFood.add(new GetData("Fish","Fish Market",R.drawable.fish));
//        dataSetOfFood.add(new GetData("Dairy Milk","Bakery",R.drawable.dairymilk));
//        dataSetOfFood.add(new GetData("Ice Cream","Arun Ice Creams",R.drawable.icecream));

        ArrayList<CardView>listOfIds=new ArrayList<>();
        listOfIds.add(findViewById(R.id.itemsRow1col0));
        listOfIds.add(findViewById(R.id.itemsRow1col1));
        listOfIds.add(findViewById(R.id.itemsRow2col0));
        listOfIds.add(findViewById(R.id.itemsRow2col1));
        listOfIds.add(findViewById(R.id.itemsRow3col0));
        listOfIds.add(findViewById(R.id.itemsRow3col1));
        listOfIds.add(findViewById(R.id.itemsRow4col0));
        listOfIds.add(findViewById(R.id.itemsRow4col1));
        listOfIds.add(findViewById(R.id.itemsRow5col0));
        listOfIds.add(findViewById(R.id.itemsRow5col1));
        listOfIds.add(findViewById(R.id.itemsRow6col0));
        listOfIds.add(findViewById(R.id.itemsRow6col1));

        ArrayList<String>ItemsNamesForCardView=new ArrayList<>();
        ItemsNamesForCardView.add("Mutton Biryani");
        ItemsNamesForCardView.add("Chicken Biryani");
        ItemsNamesForCardView.add("Veg Manchurian");
        ItemsNamesForCardView.add("Veg Noodles");
        ItemsNamesForCardView.add("Lays Chips");
        ItemsNamesForCardView.add("Thums Up");
        ItemsNamesForCardView.add("Shawarma");
        ItemsNamesForCardView.add("Samosa");
        ItemsNamesForCardView.add("Ice Cream");
        ItemsNamesForCardView.add("Dairy Milk");
        ItemsNamesForCardView.add("Fish");
        ItemsNamesForCardView.add("Peanut Butter");

        ArrayList<Pair<String,Integer>>listofPricesImages=new ArrayList<>();
        listofPricesImages.add(new Pair<>("230",R.drawable.muttonbiryani));
        listofPricesImages.add(new Pair<>("200",R.drawable.chickenbiryani));
        listofPricesImages.add(new Pair<>("200",R.drawable.vegmanchurian));
        listofPricesImages.add(new Pair<>("300",R.drawable.vegnoodles));
        listofPricesImages.add(new Pair<>("30",R.drawable.chips));
        listofPricesImages.add(new Pair<>("50",R.drawable.thumsup));
        listofPricesImages.add(new Pair<>("150",R.drawable.shawarma));
        listofPricesImages.add(new Pair<>("40",R.drawable.samosa));
        listofPricesImages.add(new Pair<>("100",R.drawable.icecream));
        listofPricesImages.add(new Pair<>("200",R.drawable.dairymilk));
        listofPricesImages.add(new Pair<>("300",R.drawable.fish));
        listofPricesImages.add(new Pair<>("250",R.drawable.peanut));

        for(int i=0;i<listOfIds.size();i++){
            int ind=i;
            listOfIds.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goToActivity(ItemsNamesForCardView.get(ind), listofPricesImages.get(ind).first, listofPricesImages.get(ind).second);
                }
            });
        }
//        CardView cardView1=findViewById(R.id.itemsRow1col0);
//        cardView1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Mutton Biryani","350",R.drawable.muttonbiryani);
//            }
//        });
//        CardView cardView2=findViewById(R.id.itemsRow1col1);
//        cardView2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Chicken Biryani","230",R.drawable.chickenbiryani);
//            }
//        });
//        CardView cardView3=findViewById(R.id.itemsRow2col0);
//        cardView3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Veg Manchurian","130",R.drawable.vegmanchurian);
//            }
//        });
//        CardView cardView4=findViewById(R.id.itemsRow2col1);
//        cardView4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Veg Noodles","100",R.drawable.vegnoodles);
//            }
//        });
//        CardView cardView5=findViewById(R.id.itemsRow3col0);
//        cardView5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Lays Chips","20",R.drawable.chips);
//            }
//        });
//        CardView cardView6=findViewById(R.id.itemsRow3col1);
//        cardView6.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Thums Up","45",R.drawable.thumsup);
//            }
//        });
//        CardView cardView7=findViewById(R.id.itemsRow4col0);
//        cardView7.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Shawarma","145",R.drawable.shawarma);
//            }
//        });
//        CardView cardView8=findViewById(R.id.itemsRow4col1);
//        cardView8.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Samosa","25",R.drawable.samosa);
//            }
//        });
//
//        CardView cardView9=findViewById(R.id.itemsRow5col0);
//        cardView9.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("IceCream","90",R.drawable.icecream);
//            }
//        });
//
//        CardView cardView10=findViewById(R.id.itemsRow5col1);
//        cardView10.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("DairyMilk","100",R.drawable.dairymilk);
//            }
//        });
//        CardView cardView11=findViewById(R.id.itemsRow6col0);
//        cardView11.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Fish","230",R.drawable.fish);
//            }
//        });
//
//        CardView cardView12=findViewById(R.id.itemsRow6col1);
//        cardView12.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goToActivity("Peanut Butter","200",R.drawable.peanut);
//            }
//        });


        //Ice Creams Flavours

        TextView txtIceCreamViewAll=findViewById(R.id.txtViewAll);
        txtIceCreamViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, ViewAllActivity.class);
                intent.putExtra("IceCream",true);
                startActivity(intent);
            }
        });
        TextView txtBiryaniViewALl=findViewById(R.id.txtViewAll2);
        txtBiryaniViewALl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ViewAllActivity.class);
                intent.putExtra("Biryani1",true);
                startActivity(intent);
            }
        });
        TextView txtSnacksViewAll=findViewById(R.id.txtViewAll3);
        txtSnacksViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ViewAllActivity.class);
                intent.putExtra("Snacks",true);
                startActivity(intent);
            }
        });
    }
    public void goToActivity(String foodName,String foodPrice,int foodImage){
        Intent intent=new Intent(MainActivity.this, ItemsCart.class);
        intent.putExtra("FoodName",foodName);
        intent.putExtra("FoodPrice",foodPrice);
        intent.putExtra("FoodImage",foodImage);
        startActivity(intent);
    }
    public void setBottomHere(LinearLayout bottomBar){
        bottomBar.setVisibility(View.VISIBLE);
    }
    public int getTotalItems(){
        return sp.getInt(COUNT,0);
    }

    public void updateBottomBar(){
        sp = getSharedPreferences("CheckOut",MODE_PRIVATE);
        editor = sp.edit();
        int k = sp.getInt("count",0);
//        itemCount.setText(Integer.toString(getTotalItems()));
        if(sp.getBoolean("isVisible",false)){
            bottomBar.setVisibility(View.VISIBLE);
            itemCount.setText(Integer.toString(getTotalItems()));
        }
        else {
            bottomBar.setVisibility(View.INVISIBLE);
        }
    }
}
