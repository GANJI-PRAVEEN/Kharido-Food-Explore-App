package com.example.cardview.Files;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cardview.R;

import org.w3c.dom.Text;

import kotlinx.coroutines.channels.Receive;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView txtFoodName;
    TextView txtFoodPrice;
    ImageView foodImageView;
    Button btnAdd;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        txtFoodName=itemView.findViewById(R.id.foodName);
        txtFoodPrice=itemView.findViewById(R.id.foodPrice);
        foodImageView=itemView.findViewById(R.id.foodImageView);
        btnAdd=itemView.findViewById(R.id.btnAdd);
    }
}
